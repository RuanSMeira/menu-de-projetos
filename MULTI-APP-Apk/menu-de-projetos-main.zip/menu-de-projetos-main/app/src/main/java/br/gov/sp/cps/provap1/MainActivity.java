package br.gov.sp.cps.provap1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import br.gov.sp.cps.provap1.prjFelicidade.FelicidadeActivity;
import br.gov.sp.cps.provap1.prjIMC.IMCActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button btnIMC = findViewById(R.id.btnImc);
        Button btnJokenpo = findViewById(R.id.btnJokenpo);
        Button btnMegaSena = findViewById(R.id.btnMegaSena);
        Button btnQuestionario = findViewById(R.id.btnQuestionario);

        btnIMC.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, IMCActivity.class);
            startActivity(intent);
        });

        btnJokenpo.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, JokenpoActivity.class);
            startActivity(intent);
        });

        btnMegaSena.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MegasenaActivity.class);
            startActivity(intent);
        });

        btnQuestionario.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FelicidadeActivity.class);
            startActivity(intent);
        });
    }
}